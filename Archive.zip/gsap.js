console.clear();
let dur = 2.5;
const tl = gsap.timeline();
document.querySelector("#action").addEventListener("click", doCoolStuff);
document.querySelector("#masterTextPath").textContent = "Hello mother fucker scdcs."
tl.from("#masterTextPath", {
  duration: dur,
  attr: { startOffset: "100%" },
  ease: "power1.inOut"
});

tl.reversed(true)

function doCoolStuff() {
  tl.reversed(!tl.reversed());
}
